#!/data/data/com.termux/files/usr/bin/bash

# ML Helper - Mobile Legends Assistant Tool
# By: PTRXOfficial (Surya)

clear
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║           ML HELPER - MOBILE LEGENDS ASSISTANT                ║"
echo "║                  Installation Script                          ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

# Check Termux
if [ ! -d "/data/data/com.termux" ]; then
    echo "❌ This script requires Termux!"
    exit 1
fi

echo "📦 Installing dependencies..."
echo ""

# Update packages
echo "⚙️  Updating Termux packages..."
pkg update -y

# Install Python
echo "🐍 Installing Python..."
pkg install python -y

# Install required packages
echo "📚 Installing Python libraries..."
pip install --upgrade pip
pip install flask requests colorama pillow

# Install Android utilities
echo "📱 Installing Termux API..."
pkg install termux-api -y

# Create directories
echo "📁 Creating project structure..."
mkdir -p ml-helper/{data,static,templates,assets}

echo ""
echo "✅ Installation complete!"
echo ""
echo "📝 Next steps:"
echo "1. Download hero data: bash download-data.sh"
echo "2. Start ML Helper: python ml_helper.py"
echo ""
