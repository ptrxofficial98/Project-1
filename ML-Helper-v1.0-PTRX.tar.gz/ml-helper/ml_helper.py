#!/usr/bin/env python3
"""
ML Helper - Mobile Legends Assistant
Floating overlay helper untuk draft pick, counter pick, build recommendations
By: PTRXOfficial
"""

import os
import json
import time
from datetime import datetime
from flask import Flask, render_template, jsonify, request
from colorama import init, Fore, Style
import threading

init(autoreset=True)

app = Flask(__name__)

# Data storage
HEROES = []
COUNTERS = {}
BUILDS = {}
MATCH_HISTORY = []

class MLHelper:
    def __init__(self):
        self.load_data()
    
    def load_data(self):
        """Load hero data, counters, builds"""
        global HEROES, COUNTERS, BUILDS
        
        # Load hero database
        hero_file = 'data/heroes.json'
        if os.path.exists(hero_file):
            with open(hero_file, 'r') as f:
                HEROES = json.load(f)
        else:
            HEROES = self.get_default_heroes()
            self.save_heroes()
        
        # Load counter data
        counter_file = 'data/counters.json'
        if os.path.exists(counter_file):
            with open(counter_file, 'r') as f:
                COUNTERS = json.load(f)
        else:
            COUNTERS = self.get_default_counters()
            self.save_counters()
        
        # Load builds
        build_file = 'data/builds.json'
        if os.path.exists(build_file):
            with open(build_file, 'r') as f:
                BUILDS = json.load(f)
        else:
            BUILDS = self.get_default_builds()
            self.save_builds()
    
    def get_default_heroes(self):
        """Default hero database"""
        return [
            # Marksman
            {"name": "Layla", "role": "Marksman", "difficulty": "Easy", "power_spike": "Late", "specialty": ["Poke", "Damage"]},
            {"name": "Miya", "role": "Marksman", "difficulty": "Easy", "power_spike": "Late", "specialty": ["Split Push", "Damage"]},
            {"name": "Claude", "role": "Marksman", "difficulty": "Medium", "power_spike": "Mid-Late", "specialty": ["Mobility", "Damage"]},
            {"name": "Wanwan", "role": "Marksman", "difficulty": "Hard", "power_spike": "Mid", "specialty": ["Mobility", "True Damage"]},
            {"name": "Beatrix", "role": "Marksman", "difficulty": "Hard", "power_spike": "All", "specialty": ["Versatile", "Poke"]},
            
            # Fighter
            {"name": "Balmond", "role": "Fighter", "difficulty": "Easy", "power_spike": "Early-Mid", "specialty": ["Regen", "Execute"]},
            {"name": "Zilong", "role": "Fighter", "difficulty": "Easy", "power_spike": "Early", "specialty": ["Split Push", "Single Target"]},
            {"name": "Chou", "role": "Fighter", "difficulty": "Hard", "power_spike": "All", "specialty": ["Crowd Control", "Mobility"]},
            {"name": "Paquito", "role": "Fighter", "difficulty": "Hard", "power_spike": "All", "specialty": ["Burst", "Mobility"]},
            {"name": "Yin", "role": "Fighter", "difficulty": "Hard", "power_spike": "Mid-Late", "specialty": ["Isolation", "Sustain"]},
            
            # Assassin
            {"name": "Saber", "role": "Assassin", "difficulty": "Easy", "power_spike": "Mid", "specialty": ["Burst", "Single Target"]},
            {"name": "Hayabusa", "role": "Assassin", "difficulty": "Hard", "power_spike": "Mid", "specialty": ["Mobility", "Burst"]},
            {"name": "Lancelot", "role": "Assassin", "difficulty": "Hard", "power_spike": "All", "specialty": ["Mobility", "Immunity"]},
            {"name": "Ling", "role": "Assassin", "difficulty": "Hard", "power_spike": "Early-Mid", "specialty": ["Mobility", "Map Control"]},
            {"name": "Fanny", "role": "Assassin", "difficulty": "Very Hard", "power_spike": "Mid", "specialty": ["Mobility", "Damage"]},
            
            # Mage
            {"name": "Eudora", "role": "Mage", "difficulty": "Easy", "power_spike": "Mid", "specialty": ["Burst", "Stun"]},
            {"name": "Nana", "role": "Mage", "difficulty": "Easy", "power_spike": "All", "specialty": ["Poke", "Crowd Control"]},
            {"name": "Kagura", "role": "Mage", "difficulty": "Hard", "power_spike": "All", "specialty": ["Mobility", "Burst"]},
            {"name": "Pharsa", "role": "Mage", "difficulty": "Medium", "power_spike": "Mid-Late", "specialty": ["Poke", "Area Damage"]},
            {"name": "Valentina", "role": "Mage", "difficulty": "Hard", "power_spike": "All", "specialty": ["Copy Ultimate", "Versatile"]},
            
            # Tank
            {"name": "Tigreal", "role": "Tank", "difficulty": "Easy", "power_spike": "All", "specialty": ["Crowd Control", "Initiate"]},
            {"name": "Franco", "role": "Tank", "difficulty": "Medium", "power_spike": "All", "specialty": ["Hook", "Crowd Control"]},
            {"name": "Khufra", "role": "Tank", "difficulty": "Medium", "power_spike": "All", "specialty": ["Anti-Dash", "Crowd Control"]},
            {"name": "Atlas", "role": "Tank", "difficulty": "Hard", "power_spike": "All", "specialty": ["Crowd Control", "Area Control"]},
            {"name": "Edith", "role": "Tank", "difficulty": "Medium", "power_spike": "All", "specialty": ["Transform", "Damage"]},
            
            # Support
            {"name": "Estes", "role": "Support", "difficulty": "Easy", "power_spike": "All", "specialty": ["Heal", "Regen"]},
            {"name": "Rafaela", "role": "Support", "difficulty": "Easy", "power_spike": "All", "specialty": ["Heal", "Speed Buff"]},
            {"name": "Diggie", "role": "Support", "difficulty": "Medium", "power_spike": "All", "specialty": ["Anti-CC", "Vision"]},
            {"name": "Mathilda", "role": "Support", "difficulty": "Hard", "power_spike": "All", "specialty": ["Mobility", "Buff"]},
            {"name": "Floryn", "role": "Support", "difficulty": "Easy", "power_spike": "All", "specialty": ["Heal", "Shield"]},
        ]
    
    def get_default_counters(self):
        """Default counter picks database"""
        return {
            "Fanny": ["Khufra", "Saber", "Eudora", "Franco", "Natalia"],
            "Wanwan": ["Franco", "Khufra", "Saber", "Natalia", "Helcurt"],
            "Claude": ["Franco", "Khufra", "Saber", "Karina", "Hayabusa"],
            "Ling": ["Saber", "Khufra", "Franco", "Natalia", "Selena"],
            "Hayabusa": ["Saber", "Franco", "Ruby", "Khufra", "Natalia"],
            "Lancelot": ["Saber", "Kaja", "Franco", "Ruby", "Eudora"],
            "Kagura": ["Natalia", "Helcurt", "Hayabusa", "Lancelot", "Fanny"],
            "Pharsa": ["Hayabusa", "Helcurt", "Natalia", "Lancelot", "Ling"],
            "Estes": ["Baxia", "Nana", "Natan", "Aamon", "Beatrix"],
            "Diggie": ["Baxia", "Zhask", "Natan", "Beatrix", "Kimmy"],
        }
    
    def get_default_builds(self):
        """Default build recommendations"""
        return {
            "Marksman": {
                "core": ["Swift Boots", "Windtalker", "Berserker's Fury", "Scarlet Phantom"],
                "situational": ["Demon Hunter Sword", "Golden Staff", "Wind of Nature", "Immortality"]
            },
            "Fighter": {
                "core": ["Warrior Boots", "War Axe", "Endless Battle", "Brute Force Breastplate"],
                "situational": ["Oracle", "Antique Cuirass", "Queen's Wings", "Immortality"]
            },
            "Assassin": {
                "core": ["Tough Boots", "Hunter Strike", "Endless Battle", "Blade of Despair"],
                "situational": ["Malefic Roar", "Rose Gold Meteor", "Immortality", "Wind of Nature"]
            },
            "Mage": {
                "core": ["Magic Shoes", "Clock of Destiny", "Lightning Truncheon", "Holy Crystal"],
                "situational": ["Genius Wand", "Divine Glaive", "Blood Wings", "Immortality"]
            },
            "Tank": {
                "core": ["Tough Boots", "Dominance Ice", "Antique Cuirass", "Athena's Shield"],
                "situational": ["Oracle", "Immortality", "Radiant Armor", "Guardian Helmet"]
            },
            "Support": {
                "core": ["Magic Shoes", "Dominance Ice", "Oracle", "Athena's Shield"],
                "situational": ["Immortality", "Necklace of Durance", "Fleeting Time", "Winter Truncheon"]
            }
        }
    
    def save_heroes(self):
        os.makedirs('data', exist_ok=True)
        with open('data/heroes.json', 'w') as f:
            json.dump(HEROES, f, indent=2)
    
    def save_counters(self):
        os.makedirs('data', exist_ok=True)
        with open('data/counters.json', 'w') as f:
            json.dump(COUNTERS, f, indent=2)
    
    def save_builds(self):
        os.makedirs('data', exist_ok=True)
        with open('data/builds.json', 'w') as f:
            json.dump(BUILDS, f, indent=2)
    
    def get_counter_picks(self, enemy_hero):
        """Get counter picks for enemy hero"""
        return COUNTERS.get(enemy_hero, [])
    
    def get_build(self, hero_role):
        """Get build recommendation for role"""
        return BUILDS.get(hero_role, {})
    
    def search_hero(self, query):
        """Search hero by name"""
        query = query.lower()
        return [h for h in HEROES if query in h['name'].lower()]

# Flask routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/heroes')
def get_heroes():
    return jsonify(HEROES)

@app.route('/api/counter/<hero>')
def get_counter(hero):
    counters = helper.get_counter_picks(hero)
    counter_details = [h for h in HEROES if h['name'] in counters]
    return jsonify({
        'hero': hero,
        'counters': counters,
        'details': counter_details
    })

@app.route('/api/build/<role>')
def get_build(role):
    build = helper.get_build(role)
    return jsonify({
        'role': role,
        'build': build
    })

@app.route('/api/search')
def search():
    query = request.args.get('q', '')
    results = helper.search_hero(query)
    return jsonify(results)

@app.route('/api/stats')
def get_stats():
    """Get game statistics"""
    return jsonify({
        'total_heroes': len(HEROES),
        'total_matches': len(MATCH_HISTORY),
        'win_rate': calculate_winrate()
    })

def calculate_winrate():
    if not MATCH_HISTORY:
        return 0
    wins = sum(1 for m in MATCH_HISTORY if m.get('result') == 'win')
    return round((wins / len(MATCH_HISTORY)) * 100, 2)

# CLI Interface
def print_banner():
    banner = f"""
{Fore.CYAN}╔═══════════════════════════════════════════════════════════════╗
║           ML HELPER - MOBILE LEGENDS ASSISTANT                ║
║                  By: PTRXOfficial                          ║
╚═══════════════════════════════════════════════════════════════╝{Style.RESET_ALL}
"""
    print(banner)

def print_menu():
    menu = f"""
{Fore.GREEN}[1]{Style.RESET_ALL} 🔍 Search Hero
{Fore.GREEN}[2]{Style.RESET_ALL} 🛡️  Counter Pick Helper
{Fore.GREEN}[3]{Style.RESET_ALL} ⚔️  Build Recommendations
{Fore.GREEN}[4]{Style.RESET_ALL} 📊 Hero Database
{Fore.GREEN}[5]{Style.RESET_ALL} 🌐 Start Web Interface (Floating Overlay)
{Fore.GREEN}[6]{Style.RESET_ALL} 📈 Match History
{Fore.GREEN}[0]{Style.RESET_ALL} ❌ Exit
"""
    print(menu)

def search_hero_cli():
    query = input(f"\n{Fore.YELLOW}Enter hero name: {Style.RESET_ALL}")
    results = helper.search_hero(query)
    
    if not results:
        print(f"{Fore.RED}No heroes found!{Style.RESET_ALL}")
        return
    
    print(f"\n{Fore.CYAN}Search Results:{Style.RESET_ALL}")
    for hero in results:
        print(f"""
{Fore.GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Style.RESET_ALL}
{Fore.YELLOW}Hero:{Style.RESET_ALL} {hero['name']}
{Fore.YELLOW}Role:{Style.RESET_ALL} {hero['role']}
{Fore.YELLOW}Difficulty:{Style.RESET_ALL} {hero['difficulty']}
{Fore.YELLOW}Power Spike:{Style.RESET_ALL} {hero['power_spike']}
{Fore.YELLOW}Specialty:{Style.RESET_ALL} {', '.join(hero['specialty'])}
""")

def counter_pick_cli():
    hero = input(f"\n{Fore.YELLOW}Enter enemy hero name: {Style.RESET_ALL}")
    counters = helper.get_counter_picks(hero)
    
    if not counters:
        print(f"{Fore.RED}No counter data for {hero}!{Style.RESET_ALL}")
        return
    
    print(f"\n{Fore.CYAN}Counter Picks for {hero}:{Style.RESET_ALL}")
    for i, counter in enumerate(counters, 1):
        print(f"{Fore.GREEN}{i}.{Style.RESET_ALL} {counter}")

def build_recommendations_cli():
    print(f"\n{Fore.CYAN}Select Role:{Style.RESET_ALL}")
    roles = list(BUILDS.keys())
    for i, role in enumerate(roles, 1):
        print(f"{Fore.GREEN}{i}.{Style.RESET_ALL} {role}")
    
    choice = input(f"\n{Fore.YELLOW}Enter number: {Style.RESET_ALL}")
    try:
        role = roles[int(choice) - 1]
        build = helper.get_build(role)
        
        print(f"\n{Fore.CYAN}Build for {role}:{Style.RESET_ALL}")
        print(f"\n{Fore.YELLOW}Core Items:{Style.RESET_ALL}")
        for item in build['core']:
            print(f"  • {item}")
        
        print(f"\n{Fore.YELLOW}Situational Items:{Style.RESET_ALL}")
        for item in build['situational']:
            print(f"  • {item}")
    except:
        print(f"{Fore.RED}Invalid choice!{Style.RESET_ALL}")

def show_hero_database():
    print(f"\n{Fore.CYAN}Hero Database ({len(HEROES)} heroes):{Style.RESET_ALL}\n")
    
    # Group by role
    roles = {}
    for hero in HEROES:
        role = hero['role']
        if role not in roles:
            roles[role] = []
        roles[role].append(hero['name'])
    
    for role, heroes in roles.items():
        print(f"{Fore.GREEN}{role}:{Style.RESET_ALL} {', '.join(heroes)}")

def start_web_interface():
    print(f"\n{Fore.CYAN}Starting Web Interface...{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}Server will run on: http://localhost:5000{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}Press Ctrl+C to stop{Style.RESET_ALL}\n")
    
    # Get local IP
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        local_ip = s.getsockname()[0]
    except:
        local_ip = '127.0.0.1'
    finally:
        s.close()
    
    print(f"{Fore.GREEN}Access from phone: http://{local_ip}:5000{Style.RESET_ALL}")
    print(f"{Fore.CYAN}Open this URL in your browser during draft pick!{Style.RESET_ALL}\n")
    
    app.run(host='0.0.0.0', port=5000, debug=False)

def main_cli():
    print_banner()
    
    while True:
        print_menu()
        choice = input(f"\n{Fore.YELLOW}Choose option: {Style.RESET_ALL}")
        
        if choice == '1':
            search_hero_cli()
        elif choice == '2':
            counter_pick_cli()
        elif choice == '3':
            build_recommendations_cli()
        elif choice == '4':
            show_hero_database()
        elif choice == '5':
            start_web_interface()
        elif choice == '6':
            print(f"{Fore.CYAN}Match History: {len(MATCH_HISTORY)} matches{Style.RESET_ALL}")
            print(f"{Fore.GREEN}Win Rate: {calculate_winrate()}%{Style.RESET_ALL}")
        elif choice == '0':
            print(f"\n{Fore.CYAN}Thanks for using ML Helper!{Style.RESET_ALL}")
            break
        else:
            print(f"{Fore.RED}Invalid option!{Style.RESET_ALL}")
        
        input(f"\n{Fore.YELLOW}Press Enter to continue...{Style.RESET_ALL}")
        os.system('clear' if os.name != 'nt' else 'cls')
        print_banner()

if __name__ == '__main__':
    helper = MLHelper()
    
    # Check if running as web server
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == '--web':
        start_web_interface()
    else:
        main_cli()
