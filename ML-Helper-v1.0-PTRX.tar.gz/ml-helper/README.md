# ML Helper - Mobile Legends Draft Pick Assistant

🎮 **ML Helper** adalah tool bantuan untuk Mobile Legends yang membantu Anda dalam draft pick, counter pick, dan build recommendations.

## ✨ Fitur

### 🔍 **Hero Search**
- Database 30+ hero populer
- Filter by role (Marksman, Fighter, Assassin, Mage, Tank, Support)
- Detail hero (difficulty, power spike, specialty)

### 🛡️ **Counter Pick Helper**
- Counter picks untuk hero meta
- Quick search untuk hero populer
- Rekomendasi 5 counter terbaik

### ⚔️ **Build Recommendations**
- Build untuk setiap role
- Core items (must have)
- Situational items (optional)
- Updated builds

### 📊 **Statistics**
- Total heroes in database
- Win rate tracking (coming soon)
- Match history (coming soon)

### 🌐 **Floating Overlay Mode**
- Web interface yang bisa dibuka di browser
- Responsive mobile design
- Bisa dipakai saat draft pick
- Quick access tanpa alt-tab

---

## 📦 Installation

### Requirements
- Termux (Android)
- Python 3.x
- Internet connection (untuk install)

### Install Steps

```bash
# 1. Clone/download package
cd ~
mkdir ml-helper
cd ml-helper

# 2. Run installer
bash install.sh

# 3. Start ML Helper
bash start.sh
```

---

## 🚀 Usage

### Mode 1: CLI (Terminal)

```bash
bash start.sh
# Pilih [1] CLI Mode
```

**Features:**
- Search hero
- Counter pick lookup
- Build recommendations
- Hero database browser

### Mode 2: Web Interface (Floating Overlay) - RECOMMENDED

```bash
bash start.sh
# Pilih [2] Web Mode
```

**How to use:**
1. Start web server di Termux
2. Note IP address yang ditampilkan (contoh: 192.168.1.5:5000)
3. Buka browser di HP
4. Akses URL: http://[IP]:5000
5. Gunakan saat draft pick ML!

**Pro Tips:**
- Bookmark URL untuk akses cepat
- Pakai split screen (browser + ML)
- Search hero musuh untuk counter picks
- Check build recommendations cepat

---

## 📱 Cara Pakai Saat Draft Pick

### Setup:
1. Start ML Helper web mode di Termux
2. Buka browser (Chrome/Firefox)
3. Access http://[local-ip]:5000
4. Masuk ke ML, mulai ranked

### Saat Draft:
1. **Enemy pick hero** → Search di ML Helper → Tab "Counter"
2. **Mau pick hero** → Check "Build" tab untuk build recommendations
3. **Cari hero spesifik** → Tab "Search" + filter by role

### Example Flow:
```
Enemy pick: Fanny
↓
Buka ML Helper → Search "Fanny" → Tab Counter
↓
Lihat counter: Khufra, Saber, Eudora, Franco
↓
Pick salah satu counter
↓
Check Build tab untuk build hero yang dipilih
```

---

## 📂 File Structure

```
ml-helper/
├── install.sh              # Installer script
├── start.sh                # Quick start script
├── ml_helper.py            # Main application
├── data/
│   ├── heroes.json         # Hero database
│   ├── counters.json       # Counter picks data
│   └── builds.json         # Build recommendations
└── templates/
    └── index.html          # Web interface
```

---

## 🎯 Hero Database

### Roles:
- **Marksman** (5 heroes): Layla, Miya, Claude, Wanwan, Beatrix
- **Fighter** (5 heroes): Balmond, Zilong, Chou, Paquito, Yin
- **Assassin** (5 heroes): Saber, Hayabusa, Lancelot, Ling, Fanny
- **Mage** (5 heroes): Eudora, Nana, Kagura, Pharsa, Valentina
- **Tank** (5 heroes): Tigreal, Franco, Khufra, Atlas, Edith
- **Support** (5 heroes): Estes, Rafaela, Diggie, Mathilda, Floryn

**Total: 30 heroes** (most popular/meta heroes)

---

## 🛠️ Customization

### Add New Hero

Edit `data/heroes.json`:

```json
{
  "name": "Hero Name",
  "role": "Role",
  "difficulty": "Easy/Medium/Hard",
  "power_spike": "Early/Mid/Late",
  "specialty": ["Specialty1", "Specialty2"]
}
```

### Add Counter Data

Edit `data/counters.json`:

```json
{
  "HeroName": ["Counter1", "Counter2", "Counter3", "Counter4", "Counter5"]
}
```

### Modify Builds

Edit `data/builds.json`:

```json
{
  "Role": {
    "core": ["Item1", "Item2", "Item3"],
    "situational": ["Item4", "Item5"]
  }
}
```

---

## 💡 Tips & Tricks

### Performance:
- Web mode lebih smooth daripada CLI
- Bookmark URL untuk akses cepat
- Pakai WiFi untuk latency rendah

### Usage:
- **Before match**: Check meta heroes & counters
- **During draft**: Quick search enemy picks
- **In game**: Reference builds (kalau lupa)

### Pro Tips:
- Study counter picks sebelum main ranked
- Hafalkan build core untuk role favorit
- Pakai quick buttons untuk hero meta

---

## 🐛 Troubleshooting

### "Connection refused" saat akses web
**Solution:**
```bash
# Check server running
ps aux | grep python

# Restart server
pkill python
bash start.sh
```

### "Module not found" error
**Solution:**
```bash
# Reinstall dependencies
pip install flask requests colorama pillow
```

### Cannot access from browser
**Solution:**
- Check IP address benar
- Check firewall/antivirus
- Make sure both devices on same WiFi
- Try http://localhost:5000 kalau di Termux

### Port already in use
**Solution:**
```bash
# Kill existing process
pkill -f "python.*ml_helper"

# Restart
bash start.sh
```

---

## 🚀 Future Features

**Planned:**
- [ ] Real-time match tracking
- [ ] Win rate calculator
- [ ] Hero tier list
- [ ] Emblem recommendations
- [ ] Spell recommendations
- [ ] Team composition analyzer
- [ ] More heroes (100+)
- [ ] More counter data
- [ ] Video guides integration

---

## 📞 Support

**Issues?**
- Check troubleshooting section
- Verify all dependencies installed
- Make sure Python 3.x installed

**Feature requests?**
- Edit hero database manually
- Modify counter picks data
- Customize builds

---

## ⚖️ Legal

**Disclaimer:**
- This is a **helper tool**, not a cheat/hack
- Does **NOT** modify game files
- Does **NOT** interact with game client
- 100% legal and safe
- Just a reference database

**Use responsibly:**
- Don't rely 100% on counter picks
- Skill > counter picks
- Practice your mechanics
- Have fun!

---

## 👨‍💻 Credits

**Created by:** PTRXOfficial
**Version:** 1.0
**Date:** July 2026

**Thanks to:**
- Mobile Legends community
- ML pro players for meta insights

---

## 📜 License

MIT License - Free to use and modify

---

**🎮 ENJOY YOUR GAMES! GOOD LUCK IN RANKED! 🏆**

---

## Quick Start Guide

```bash
# Install
bash install.sh

# Start (Web Mode)
bash start.sh
# Choose [2]

# Access
Open browser: http://[ip]:5000

# During Draft Pick
Search enemy hero → Check counters → Pick counter
```

**That's it! Happy gaming! 🎮**
