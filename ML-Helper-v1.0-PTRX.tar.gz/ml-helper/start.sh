#!/data/data/com.termux/files/usr/bin/bash

# ML Helper - Quick Start Script
# By: PTRXOfficial (Surya)

clear

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║           ML HELPER - QUICK START                             ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

# Check if installed
if [ ! -f "ml_helper.py" ]; then
    echo "❌ ML Helper not installed!"
    echo "📦 Run: bash install.sh"
    exit 1
fi

echo "🚀 Starting ML Helper..."
echo ""
echo "Choose mode:"
echo "[1] CLI Mode (Terminal)"
echo "[2] Web Mode (Floating Overlay)"
echo ""

read -p "Enter choice [1-2]: " choice

case $choice in
    1)
        python ml_helper.py
        ;;
    2)
        echo ""
        echo "🌐 Starting Web Interface..."
        echo "📱 Open browser on your phone and go to:"
        echo ""
        
        # Get local IP
        IP=$(ip addr show wlan0 | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
        if [ -z "$IP" ]; then
            IP="localhost"
        fi
        
        echo "   http://$IP:5000"
        echo ""
        echo "💡 Use this during draft pick!"
        echo "⚠️  Press Ctrl+C to stop"
        echo ""
        
        python ml_helper.py --web
        ;;
    *)
        echo "❌ Invalid choice!"
        ;;
esac
