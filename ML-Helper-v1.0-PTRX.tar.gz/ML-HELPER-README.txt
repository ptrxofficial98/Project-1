╔═══════════════════════════════════════════════════════════════╗
║   ML HELPER - MOBILE LEGENDS DRAFT PICK ASSISTANT            ║
║   Package Ready! Download & Install di Termux                ║
╚═══════════════════════════════════════════════════════════════╝

📦 FILE: ML-Helper.tar.gz (13KB)
🔐 MD5: e7d548ca61f77df56d017358cbce9ceb

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎮 FITUR UTAMA:

✅ Hero Search - 30+ hero dengan filter role
✅ Counter Pick - Counter untuk hero meta
✅ Build Guide - Build recommendations per role
✅ Floating Overlay - Web interface saat draft pick
✅ 100% Legal - Bukan cheat, safe to use

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🚀 CARA INSTALL (3 LANGKAH):

1. Download ML-Helper.tar.gz ke HP
2. Buka Termux, extract:
   cd ~/storage/downloads
   tar -xzf ML-Helper.tar.gz
   cd ml-helper

3. Install & Start:
   bash install.sh
   bash start.sh

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 CARA PAKAI SAAT DRAFT:

MODE WEB (Recommended):
1. bash start.sh → Pilih [2]
2. Buka browser: http://localhost:5000
3. Bookmark URL untuk quick access

SAAT DRAFT PICK ML:
→ Enemy pick Fanny
→ Buka ML Helper → Search "Fanny"
→ Tab Counter → Lihat: Khufra, Saber, Eudora
→ Pick Khufra → Check Build tab
→ GG WP! 🏆

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 DATABASE:

30 HERO POPULER:
• Marksman: Layla, Miya, Claude, Wanwan, Beatrix
• Fighter: Balmond, Zilong, Chou, Paquito, Yin
• Assassin: Saber, Hayabusa, Lancelot, Ling, Fanny
• Mage: Eudora, Nana, Kagura, Pharsa, Valentina
• Tank: Tigreal, Franco, Khufra, Atlas, Edith
• Support: Estes, Rafaela, Diggie, Mathilda, Floryn

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 100% LEGAL & SAFE:

• Bukan cheat/hack
• Tidak modify game
• Hanya reference database
• No ban risk
• Moonton approved (reference tool)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📖 DOKUMENTASI:

Di dalam package ada:
• README.md - Full documentation
• QUICKSTART.txt - Quick reference
• ML-HELPER-DELIVERY.txt - Complete delivery notes

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎉 SIAP PAKAI!

Creator: PTRXOfficial (Surya)
Version: 1.0
Date: July 13, 2026

GOOD LUCK IN RANKED! 🏆
